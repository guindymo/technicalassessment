<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TopOrderingCustomerController extends Controller
{
    public function findTopOrderingCustomer()
    {
        $customer = Customer::select(DB::raw('customers.*, count(orders.id) as total_orders'))
            ->leftJoin('orders', 'customers.id', '=', 'orders.customer_id')
            ->groupBy('customers.id')
            ->orderByDesc('total_orders')
            ->first();

        return response()->json([
            'customer' => $customer
        ]);
    }
}

?>