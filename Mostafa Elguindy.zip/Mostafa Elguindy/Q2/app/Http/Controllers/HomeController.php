<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;

class HomeController extends Controller
{
    public function index()
    {
        $students = Student::all();
        $teachers = Teacher::all();

        return View::make('home', compact('students', 'teachers'));
    }
}



 ?>