<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\TeacherController;

Route::get('/', [HomeController::class, 'index']);

Route::get('/students', [StudentController::class, 'index']);
Route::get('/teachers', [TeacherController::class, 'index']); 

?>