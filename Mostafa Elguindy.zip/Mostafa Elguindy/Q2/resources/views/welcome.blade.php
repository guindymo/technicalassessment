<x-app-layout>
    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <h1 class="text-3xl font-bold mb-3">Welcome to my app!</h1>
                <p class="mb-6">Here's a list of all the students:</p>
                <ul class="mb-6">
                    @foreach ($students as $student)
                        <li>{{ $student->name }} (ID: {{ $student->id }})</li>
                    @endforeach
                </ul>
                <p class="mb-6">Here's a list of all the teachers:</p>
                <ul>
                    @foreach ($teachers as $teacher)
                        <li>{{ $teacher->name }} (ID: {{ $teacher->id }})</li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</x-app-layout>
