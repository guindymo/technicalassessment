require('./bootstrap');
require('alpinejs');

setInterval(() => {
  axios.get('/students').then(response => {
    let students = response.data;
    let html = '';
    students.forEach(student => {
      html += `<div class="border-2 p-2 mb-2 rounded-lg">
                  <h2 class="text-xl font-bold">${student.name}</h2>
                  <p class="text-gray-700">ID: ${student.id}</p>
                  <p class="text-gray-700">Roll No: ${student.roll_no}</p>
                </div>`;
    });
    document.querySelector('#students').innerHTML = html;
  });
}, 10000);

setInterval(() => {
  axios.get('/teachers').then(response => {
    let teachers = response.data;
    let html = '';
    teachers.forEach(teacher => {
      html += `<div class="border-2 p-2 mb-2 rounded-lg">
                  <h2 class="text-xl font-bold">${teacher.name}</h2>
                  <p class="text-gray-700">ID: ${teacher.id}</p>
                  <p class="text-gray-700">Department: ${teacher.department}</p>
                </div>`;
    });
    document.querySelector('#teachers').innerHTML = html;
  });
}, 10000);
