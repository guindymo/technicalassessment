<?php



// app/Http/Livewire/StudentComponent.php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Student;

class StudentComponent extends Component
{
    use WithFileUploads;

    public $students, $name, $grade, $department, $image, $student_id;
    public $isModalOpen = 0;

    public function render()
    {
        $this->students = Student::all();
        return view('livewire.student-component');
    }

    public function create()
    {
        $this->validate([
            'name' => 'required',
            'grade' => 'required',
            'department' => 'required',
            'image' => 'image|max:1024', // 1MB Max
        ]);

        $imageName = time().'.'.$this->image->extension();
        $this->image->storeAs('public/images', $imageName);

        Student::create([
            'name' => $this->name,
            'grade' => $this->grade,
            'department' => $this->department,
            'image' => $imageName
        ]);

        session()->flash('message', 'Student Created Successfully.');
        $this->closeModal();
        $this->resetInputFields();
    }

    public function edit($id)
    {
        $student = Student::findOrFail($id);
        $this->student_id = $id;
        $this->name = $student->name;
        $this->grade = $student->grade;
        $this->department = $student->department;
        $this->isModalOpen = true;
    }

    public function update()
    {
        $this->validate([
            'name' => 'required',
            'grade' => 'required',
            'department' => 'required',
            'image' => 'image|max:1024', // 1MB Max
        ]);

        $student = Student::find($this->student_id);

        if ($this->image) {
            $imageName = time().'.'.$this->image->extension();
            $this->image->storeAs('public/images', $imageName);
            $student->image = $imageName;
        }

        $student->name = $this->name;
        $student->grade = $this->grade;
        $student->department = $this->department;

        $student->save();

        session()->flash('message', 'Student Updated Successfully.');
        $this->closeModal();
        $this->resetInputFields();
    }

    public function delete($id)
    {
        Student::find($id)->delete();
        session()->flash('message', 'Student Deleted Successfully.');
    }

    public function createModal()
    {
        $this->resetInputFields();
        $this->isModalOpen = true;
    }

    public function closeModal()
    {
        $this->isModalOpen = false;
    }

    private function resetInputFields()
    {
        $this->name = '';
        $this->grade = '';
        $this->department = '';
        $this->image = '';
        $this->student_id = '';
    }
}



 ?>