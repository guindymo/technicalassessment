<?php 

// routes/web.php

use App\Http\Livewire\StudentComponent;

Route::get('/', function () {
    return view('welcome');
});

Route::get('students', StudentComponent::class)->name('students');




?>