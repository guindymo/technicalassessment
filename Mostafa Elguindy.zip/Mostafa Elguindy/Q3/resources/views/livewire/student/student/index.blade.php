<div>
    @if(session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
    @endif
    <button wire:click="create()" class="btn btn-success">Create New Student</button>
    <br><br>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No.</th>
                <th>Name</th>
                <th>Grade</
<th>ID</th>
                <th>Department</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($students as $student)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $student->name }}</td>
                <td>{{ $student->grade }}</td>
                <td>{{ $student->department }}</td>
                <td>
                    <button wire:click="edit({{ $student->id }})" class="btn btn-primary btn-sm">Edit</button>
                    <button wire:click="delete({{ $student->id }})" class="btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <!-- Modal Form -->
    <div class="modal fade" wire:ignore.self id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">{{ $isOpen ? 'Edit Student' : 'Create Student' }}</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true" wire:click="closeModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="{{ $isOpen ? 'update' : 'store' }}">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" placeholder="Enter Name" wire:model="name">
                            @error('name') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label for="grade">Grade</label>
                            <input type="text" class="form-control" id="grade" placeholder="Enter Grade" wire:model="grade">
                            @error('grade') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <div class="form-group">
                            <label for="department">Department</label>
                            <input type="text" class="form-control" id="department" placeholder="Enter Department" wire:model="department">
                            @error('department') <span class="text-danger">{{ $message }}</span>@enderror
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" wire:click="closeModal()">Close</button>
                        <button type="submit" class="btn btn-primary">{{ $isOpen ? 'Update' : 'Create' }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
