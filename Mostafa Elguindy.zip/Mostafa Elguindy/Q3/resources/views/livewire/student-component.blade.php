<!-- resources/views/livewire/student-component.blade.php -->

<div>
    <div class="max-w-7xl mx-auto py-10 sm:px-6 lg:px-8">
        <div class="flex justify-between mb-4">
            <div class="flex">
                <span class="mr-2 rounded-md shadow-sm">
                    <button wire:click="createModal" class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-500 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:shadow-outline-indigo disabled:opacity-25 transition ease-in-out duration-150">
                        Add Student
                    </button>
                </span>
                @if(session()->has('message'))
                    <div class="px-4 py-2 bg-green-400 rounded-md text-white text-sm">
                        {{ session('message') }}
                    </div>
                @endif
            </div>
            <div>
                <input wire:model="search" type="text" class="w-full px-3 py-2 rounded-lg border-2 border-gray-200 bg-white focus:outline-none focus:border-indigo-500" placeholder="Search...">
            </div>
        </div>

        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Grade
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Department
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Image
                    </th>
                    <th scope="col" class="relative px-6 py-3">
                        <span class="sr-only">Edit</span>
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                @foreach($students as $student)
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            {{ $student->id }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            {{ $student->name }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            {{ $student->grade }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            {{ $student->department }}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            @if($student->image)
                                <img src="{{ Storage::url('images/' . $student->image) }}" alt="{{ $student->name }}" class="w-20">
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                           
                            <div class="flex justify-end items-center">
                                <button wire:click="editModal({{ $student->id }})" class="text-indigo-600 hover:text-indigo-900">Edit</button>
                                <button wire:click="deleteModal({{ $student->id }})" class="text-red-600 hover:text-red-900 ml-2">Delete</button>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        {{ $students->links() }}

    </div>

    <!-- Create and Update Student Modal -->
    <x-jet-dialog-modal wire:model="modalFormVisible">
        <x-slot name="title">
            {{ $modelId ? 'Update Student' : 'Create Student' }}
        </x-slot>

        <x-slot name="content">
            <div class="mt-4">
                <x-jet-label for="name" value="Name" />
                <x-jet-input id="name" class="block mt-1 w-full" type="text" wire:model.debounce.500ms="name" />
                @error('name') <span class="text-red-500">{{ $message }}</span>@enderror
            </div>

            <div class="mt-4">
                <x-jet-label for="grade" value="Grade" />
                <x-jet-input id="grade" class="block mt-1 w-full" type="number" min="0" max="100" wire:model.debounce.500ms="grade" />
                @error('grade') <span class="text-red-500">{{ $message }}</span>@enderror
            </div>

            <div class="mt-4">
                <x-jet-label for="department" value="Department" />
                <select id="department" class="form-select w-full" wire:model.debounce.500ms="department">
                    <option value="">Choose Department</option>
                    <option value="Computer Science">Computer Science</option>
                    <option value="Mathematics">Mathematics</option>
                    <option value="Physics">Physics</option>
                    <option value="Biology">Biology</option>
                </select>
                @error('department') <span class="text-red-500">{{ $message }}</span>@enderror
            </div>

            <div class="mt-4">
                <x-jet-label for="image" value="Image" />
                <input type="file" id="image" class="block mt-1 w-full" wire:model="image" accept="image/*">
                @if($image)
                    <img src="{{ $image->temporaryUrl() }}" alt="{{ $name }}" class="mt-2 w-20">
                @endif
                @error('image') <span class="text-red-500">{{ $message }}</span>@enderror
            </div>
        </x-slot>

        <x-slot name="footer">
            <x-jet-secondary-button wire:click="$toggle('modalFormVisible')" wire:loading.attr="disabled">
                Cancel
            </x-jet-secondary-button>

            @if($modelId)
                <x-jet-danger-button class="ml-2" wire:click="update" wire:loading.attr="disabled">
                    Update
                </x-jet-danger-button>
            @else
                <x-jet-button class="ml-2" wire:click="create" wire:loading.attr="disabled">
                    Create
                </x-jet-button>
            @endif
        </x-slot>
    </x-jet-dialog-modal>

    <!-- Delete Student Modal -->
    <x-jet-dialog-modal wire:model="modalConfirmDeleteVisible">
        <x-slot name="title">
            {{ __('Delete Student') }}
        </x-slot>

        <x-slot name="content">
            {{ __('Are you sure you want to delete this student?') }}
        </x-slot>

        <x-slot name="footer">
            <x-jet-secondary-button wire:click="$toggle('modalConfirmDeleteVisible')" wire:loading.attr="disabled">
                {{ __('Cancel') }}
            </x-jet-secondary-button>

            <x-jet-danger-button class="ml-2" wire:click="delete" wire:loading.attr="disabled">
                {{ __('Delete') }}
            </x-jet-danger-button>
        </x-slot>
    </x-jet-dialog-modal>
</div>
